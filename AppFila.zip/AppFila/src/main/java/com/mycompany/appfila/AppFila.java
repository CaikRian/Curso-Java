/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.appfila;

/**
 *
 * @author 2110810
 */
public class AppFila {

    public static void main(String[] args) {
        ClienteDoCinema c1 = new ClienteDoCinema(1, "joao", "HP");
        ClienteDoCinema c2 = new ClienteDoCinema(2, "maria", "Clude de Lita");
        ClienteDoCinema c3 = new ClienteDoCinema(3, "josé", "Frozen");
        ClienteDoCinema c4 = new ClienteDoCinema(4, "josefina", "Naruto");
        ClienteDoCinema c5 = new ClienteDoCinema(5, "marcos", "Star Wars");
        //ClienteDoCinema c6 = new ClienteDoCinema(6, "marcia", "Barbie");
        
        try{
            FilaLinear f = new FilaLinear();
            f.enfileira(c1);
            f.enfileira(c2);
            f.enfileira(c3);
            f.enfileira(c4);
            f.enfileira(c5);
            //f.enfileira(c6);
            
            while (!f.estaVazia()){
                ClienteDoCinema cx = f.desenfileira();
                System.out.println(cx);
                
            }
         
        }catch(Exception e){
            System.out.println(e.getMessage());
        }


    }
}
