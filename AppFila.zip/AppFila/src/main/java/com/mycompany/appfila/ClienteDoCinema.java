/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.appfila;

/**
 *
 * @author 2110810
 */
public class ClienteDoCinema {
    private int ingresso; // exclusivo para cada cliente
    private String nome;
    private String filme;
    
    
    public ClienteDoCinema(){
        
    }
    
    public ClienteDoCinema(int ingresso, String nome){
        this.ingresso = ingresso;
        this.nome = nome;
        
    }
    
    public ClienteDoCinema(int ingresso, String nome, String filme){
        this.ingresso = ingresso;
        this.nome = nome;
        this.filme = filme;
    }

    /**
     * @return the ingresso
     */
    public int getIngresso() {
        return ingresso;
    }

    /**
     * @param ingresso the ingresso to set
     */
    public void setIngresso(int ingresso) {
        this.ingresso = ingresso;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the filme
     */
    public String getFilme() {
        return filme;
    }

    /**
     * @param filme the filme to set
     */
    public void setFilme(String filme) {
        this.filme = filme;
    }
    
    @Override
    public String toString(){
    return this.getIngresso() + "|" + this.getNome() + "|" +this.getFilme();
    }
    
}
