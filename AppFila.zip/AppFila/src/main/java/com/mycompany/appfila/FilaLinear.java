/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.appfila;

/**
 *
 * @author 2110810
 */
public class FilaLinear {
    private int quantidade;
    private int tamanhoMaximo;
    private int inicio, fim;
    private ClienteDoCinema[] lista;
    
    public FilaLinear(){
        this.quantidade = 0;
        this.tamanhoMaximo = 5;
        this.inicio = 0;
        this.fim = tamanhoMaximo - 1;
        this.lista = new ClienteDoCinema[tamanhoMaximo];
    }
    
    public boolean estaCheia(){// verifica se a fila está cheia
        return (this.quantidade == this.tamanhoMaximo);
    }
    public boolean estaVazia(){ // verifica se a fila está vazia
        return (this.quantidade == 0);
    }
    public int getTamanhoDaFila(){//exibe o tamanho da fila
        return this.quantidade;
    }
    
    public void enfileira(ClienteDoCinema c) throws Exception{
        if(!this.estaCheia()){
            //enfileirar aqui
            this.fim = (this.fim +1) % this.tamanhoMaximo;
            this.lista[this.fim] = c;
            this.quantidade++;
        } else {
            throw new Exception("A fila está cheia");
        }
    }
    
    public ClienteDoCinema desenfileira() throws Exception{
        
        if(!this.estaVazia()){
            
            ClienteDoCinema c = this.lista[this.inicio];
            this.inicio = (this.inicio + 1) % this.tamanhoMaximo;
            this.quantidade--;
            return c;
            
        }else {
            throw new Exception("A fila está vazia");
        }
    }
 
    
}
