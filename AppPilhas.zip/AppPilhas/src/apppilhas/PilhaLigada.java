/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package apppilhas;

/**
 *
 * @author orlandojunior
 */
public class PilhaLigada implements IPilha {

    private int quantidade;
    private int TamanhoMaximoDaPilha = 1000;
    private Celula topo;

    public PilhaLigada() {
        this.quantidade = 0;
        this.topo = null;
    }

    @Override
    public void empilha(int n) throws Exception {
        if (this.quantidade < this.TamanhoMaximoDaPilha) {
            Celula aux = this.topo;
            this.topo = new Celula(n);
            this.topo.setProximo(aux);
            this.quantidade++;
        } else {
            throw new Exception("A pilha está cheia.");
        }
    }

    @Override
    public int desempilha() throws Exception {
        if (this.quantidade != 0) {
            int n = this.topo.getValor();
            this.topo = this.topo.getProximo();
            this.quantidade--;
            return n;
        } else {
            throw new Exception("A pilha está vazia.");
        }
    }

}
