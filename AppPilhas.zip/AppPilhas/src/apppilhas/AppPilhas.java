/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package apppilhas;

/**
 *
 * @author orlandojunior
 */
public class AppPilhas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       /* PilhaLigada pl = new PilhaLigada();

        int i = 0;
        try {

            for (; i < 2000; i++) {
                pl.empilha(i);
            }

        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        System.out.println("i = " + i);
        System.out.println("Fim da execução");
        
        */
        PilhaSequencial p2 = new PilhaSequencial();
        
        int i = 0;
        try{
            for (; i <= 1000001; i++) {
                p2.empilha(i);
            }
        }
        catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        
        //System.out.println(p2.estaVazia()); //Verifica se a pilha está vazia
        //System.out.println(p2.getTamanho()); //Retorna o tamanho da Pilha
        //System.out.println(p2.esvazia()); // Esvazia a pilha 
        //System.out.println(p2.peek()); //Retorna o topo da pilha
  
  
    }
}
