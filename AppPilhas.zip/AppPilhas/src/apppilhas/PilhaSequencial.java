/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package apppilhas;

/**
 *
 * @author orlandojunior
 */
public class PilhaSequencial implements IPilha {

    private int quantidade;
    private int TamanhoMaximoDaPilha = 1000001;
    private int[] lista;

    public PilhaSequencial() {
        this.quantidade = 0;
        this.lista = new int[this.TamanhoMaximoDaPilha];
    }

    @Override
    public void empilha(int n) throws Exception {
        if (this.quantidade != this.TamanhoMaximoDaPilha) {
            this.lista[this.quantidade] = n;
            this.quantidade++;
        } else {
            throw new Exception("A pilha está cheia.");
        }
    }

    @Override
    public int desempilha() throws Exception {
        if (this.quantidade != 0) {
            --this.quantidade;
            return this.lista[this.quantidade];
        } else {
            throw new Exception("A pilha está vazia.");
        }
    }
    
    public boolean estaVazia(){
        return (this.quantidade == 0);
    }
    
    public int esvazia(){
        return this.quantidade = 0;
    }
    
    public int getTamanho(){
        return this.quantidade;
    }
    
    public int peek(){
        return (this.lista[this.quantidade-1]);
    }
}

