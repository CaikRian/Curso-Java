/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package apppilhas;

/**
 *
 * @author 2110810
 */
public class ConversãoBinario {
    
    private int quantidade;
    private int TamanhoMaximoDaPilha = 2;
    private int[] lista;
   

    public ConversãoBinario() {
        this.quantidade = 0;
        this.lista = new int[this.TamanhoMaximoDaPilha];
    }
    
    public void calcBinario(int numero){
        
 
        
    }
    //@Override
    public void empilha(int n) throws Exception {
        if (this.quantidade != this.TamanhoMaximoDaPilha) {
            this.lista[this.quantidade] = n;
            this.quantidade++;
        } else {
            throw new Exception("A pilha está cheia.");
        }
    }
    
}
